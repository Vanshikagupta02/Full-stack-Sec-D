SET B SOLUTIONS

Practical B1 - JWT Authentication API
1. Open Practical_B1_JWT_API
2. Run: npm install
3. Run: npm start
4. Server runs on port 3000.

Practical B2 - Shopping Cart with Discount
Cart.jsx and App.jsx are provided.
Place these files in the src folder of a React project.
