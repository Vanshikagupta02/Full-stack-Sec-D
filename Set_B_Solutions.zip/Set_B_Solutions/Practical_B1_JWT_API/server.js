const express = require("express");
const jwt = require("jsonwebtoken");

const app = express();
app.use(express.json());

const SECRET_KEY = "mysecretkey";
const users = [];

// POST /register
app.post("/register", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password || username.length < 6) {
        return res.status(400).json({ error: "Invalid input" });
    }

    const existingUser = users.find(user => user.username === username);
    if (existingUser) {
        return res.status(409).json({ error: "Username already exists" });
    }

    users.push({ username, password });
    res.status(201).json({ message: "User registered" });
});

// POST /login
app.post("/login", (req, res) => {
    const { username, password } = req.body;

    const user = users.find(
        user => user.username === username && user.password === password
    );

    if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
    }

    const token = jwt.sign(
        { username: user.username },
        SECRET_KEY,
        { expiresIn: "1h" }
    );

    res.status(200).json({ token });
});

function verifyToken(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ error: "Unauthorized" });
    }

    const token = authHeader.split(" ")[1];

    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(401).json({ error: "Unauthorized" });
    }
}

// GET /profile
app.get("/profile", verifyToken, (req, res) => {
    res.status(200).json({ username: req.user.username });
});

app.listen(3000, () => {
    console.log("Server running on port 3000");
});
