import Cart from "./Cart";

function App() {
    const products = [
        { id: 1, name: "T-Shirt", price: 50 },
        { id: 2, name: "Shoes", price: 80 },
        { id: 3, name: "Bag", price: 40 }
    ];

    return <Cart products={products} />;
}

export default App;
