import React, { useState } from "react";

export default function Cart({ products }) {
    const [quantities, setQuantities] = useState({});

    const add = (id) => {
        setQuantities({
            ...quantities,
            [id]: (quantities[id] || 0) + 1
        });
    };

    const dec = (id) => {
        setQuantities({
            ...quantities,
            [id]: Math.max((quantities[id] || 0) - 1, 0)
        });
    };

    const remove = (id) => {
        setQuantities({
            ...quantities,
            [id]: 0
        });
    };

    const total = products.reduce(
        (sum, p) => sum + p.price * (quantities[p.id] || 0),
        0
    );

    const discount = total > 100 ? total * 0.10 : 0;
    const grandTotal = total - discount;

    const cartEmpty = Object.values(quantities).every(qty => qty === 0);

    return (
        <div>
            <h2>Shopping Cart</h2>

            {products.map(product => (
                <div key={product.id}>
                    <h3>{product.name}</h3>
                    <p>Price: ₹{product.price}</p>

                    <button
                        data-testid={`add-${product.id}`}
                        onClick={() => add(product.id)}
                    >
                        Add
                    </button>

                    <p data-testid={`qty-${product.id}`}>
                        Quantity: {quantities[product.id] || 0}
                    </p>

                    <button
                        data-testid={`dec-${product.id}`}
                        onClick={() => dec(product.id)}
                    >
                        Decrease
                    </button>

                    <button
                        data-testid={`remove-${product.id}`}
                        onClick={() => remove(product.id)}
                    >
                        Remove
                    </button>
                </div>
            ))}

            {cartEmpty && <p className="cart-empty">Cart is empty.</p>}

            <h3>Total: {total.toFixed(2)}</h3>

            {total > 100 && <h3>Discount: {discount.toFixed(2)}</h3>}

            <h3>Grand Total: {grandTotal.toFixed(2)}</h3>
        </div>
    );
}
